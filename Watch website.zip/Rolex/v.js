const u={
    name:"ravi",
    age:23,
    job:"programer"
};
const keys=Object.keys(u);
keys.forEach(key=> {
    console.log(`${key}:${u[key]}`);
});